//
//  MyTableViewController.swift
//  apiTest2
//
//  Created by Hamza on 1/24/20.
//  Copyright © 2020 Hamza. All rights reserved.
//

import UIKit

class MyTableViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

     
        // Do any additional setup after loading the view.
    }
    
    var arrayVal : [Int] = [1,2,3,4,5]
  

}


