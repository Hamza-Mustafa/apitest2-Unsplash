//
//  Configuration.swift
//  UnsplashPhotoPicker
//
//  Created by Bichon, Nicolas on 2018-10-09.
//  Copyright © 2018 Unsplash. All rights reserved.
//

import Foundation

struct Configuration {
    static var shared: UnsplashPhotoPickerConfiguration = UnsplashPhotoPickerConfiguration()
}
